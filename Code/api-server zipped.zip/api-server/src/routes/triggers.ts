import { Router, type IRouter } from "express";
import { db, claimsTable, workersTable, policiesTable, disruptionEventsTable } from "@workspace/db";
import { eq, and, gt, desc } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";
import { CheckParametricTriggersBody, GetCurrentWeatherQueryParams } from "@workspace/api-zod";
import { fetchWeatherData, getMockTrafficData, WEATHER_THRESHOLD, TRAFFIC_THRESHOLD } from "../lib/weather-service";
import { runFraudSentry } from "../lib/fraud-sentry";
import { randomBytes } from "crypto";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.post("/triggers/check", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = CheckParametricTriggersBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { workerId, lat, lon, devicePressure, mockLocationDetected, systemIntegrityFlag } = parsed.data;

  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, workerId));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const weatherData = await fetchWeatherData(lat, lon);
  const trafficData = getMockTrafficData(lat, lon);

  let triggered = false;
  let triggerType = "none";
  let triggerValue = 0;
  let threshold = 0;
  let claimCreated = false;
  let claimId: number | null = null;
  let message = "No parametric trigger conditions met.";

  const now = new Date();
  const [activePolicy] = await db.select().from(policiesTable).where(
    and(
      eq(policiesTable.workerId, workerId),
      eq(policiesTable.status, "active"),
      gt(policiesTable.endDate, now)
    )
  ).orderBy(desc(policiesTable.createdAt)).limit(1);

  if (weatherData.rainfall > WEATHER_THRESHOLD) {
    triggered = true;
    triggerType = "weather";
    triggerValue = weatherData.rainfall;
    threshold = WEATHER_THRESHOLD;
    message = `Rainfall of ${weatherData.rainfall.toFixed(1)}mm exceeds threshold of ${WEATHER_THRESHOLD}mm. Parametric trigger activated.`;
  } else if (trafficData.delayMinutes > TRAFFIC_THRESHOLD) {
    triggered = true;
    triggerType = "traffic";
    triggerValue = trafficData.delayMinutes;
    threshold = TRAFFIC_THRESHOLD;
    message = `Traffic delay of ${trafficData.delayMinutes} mins exceeds threshold of ${TRAFFIC_THRESHOLD} mins. Parametric trigger activated.`;
  }

  if (triggered && activePolicy) {
    const fraudResult = runFraudSentry({
      devicePressure: devicePressure ?? null,
      stationPressure: weatherData.pressure,
      mockLocationDetected: mockLocationDetected ?? null,
      systemIntegrityFlag: systemIntegrityFlag ?? null,
      rainfall: triggerValue,
      triggerType,
    });

    const status = fraudResult.isFlagged ? "conditional_payout" : "approved";
    const handshakeCode = fraudResult.isFlagged ? randomBytes(4).toString("hex").toUpperCase() : null;

    const [claim] = await db.insert(claimsTable).values({
      workerId,
      policyId: activePolicy.id,
      triggerType,
      triggerValue,
      triggerThreshold: threshold,
      status,
      payoutAmount: activePolicy.coverageAmount,
      fraudScore: fraudResult.fraudScore,
      fraudFlags: fraudResult.fraudFlags,
      isFlagged: fraudResult.isFlagged,
      handshakeCode,
    }).returning();

    await db.insert(disruptionEventsTable).values({
      city: worker.city,
      lat: worker.lat,
      lon: worker.lon,
      type: triggerType,
      severity: triggerValue > threshold * 2 ? "High" : triggerValue > threshold * 1.3 ? "Medium" : "Low",
      value: triggerValue,
      affectedWorkers: 1,
      claimsTriggered: 1,
      timestamp: new Date(),
    });

    claimCreated = true;
    claimId = claim!.id;

    if (fraudResult.isFlagged) {
      message += ` Claim flagged for FraudSentry review (score: ${fraudResult.fraudScore}). Digital handshake required.`;
    }

    logger.info({ claimId, workerId, triggerType, fraudResult }, "Parametric trigger fired, claim created");
  } else if (triggered && !activePolicy) {
    message += " No active policy found — claim not created.";
  }

  res.json({
    triggered,
    triggerType,
    triggerValue,
    threshold,
    claimCreated,
    claimId,
    message,
    weatherData,
    trafficData,
  });
});

router.get("/triggers/weather", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = GetCurrentWeatherQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const weather = await fetchWeatherData(parsed.data.lat, parsed.data.lon);
  res.json(weather);
});

export default router;
