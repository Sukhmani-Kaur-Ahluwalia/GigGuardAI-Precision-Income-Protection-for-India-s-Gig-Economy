import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { Request, Response, NextFunction } from "express";

const JWT_SECRET = process.env.JWT_SECRET ?? process.env.SESSION_SECRET ?? "gigguard-secret-key-2024";
const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(workerId: number): string {
  return jwt.sign({ workerId }, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): { workerId: number } {
  return jwt.verify(token, JWT_SECRET) as { workerId: number };
}

export interface AuthenticatedRequest extends Request {
  workerId?: number;
}

export function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const token = authHeader.slice(7);
  try {
    const payload = verifyToken(token);
    req.workerId = payload.workerId;
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}
