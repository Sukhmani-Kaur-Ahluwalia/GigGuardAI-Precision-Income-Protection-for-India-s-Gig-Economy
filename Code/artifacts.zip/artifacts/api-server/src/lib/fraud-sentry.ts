import { logger } from "./logger";

export interface FraudInput {
  devicePressure?: number | null;
  stationPressure: number;
  mockLocationDetected?: boolean | null;
  systemIntegrityFlag?: string | null;
  rainfall: number;
  triggerType: string;
}

export interface FraudResult {
  fraudScore: number;
  fraudFlags: string[];
  isFlagged: boolean;
}

const PRESSURE_TOLERANCE = 5;
const FRAUD_THRESHOLD = 60;

export function runFraudSentry(input: FraudInput): FraudResult {
  let fraudScore = 0;
  const fraudFlags: string[] = [];

  if (input.devicePressure != null && input.triggerType === "weather") {
    const pressureDiff = Math.abs(input.devicePressure - input.stationPressure);
    if (pressureDiff > PRESSURE_TOLERANCE * 2) {
      fraudScore += 35;
      fraudFlags.push("Altitude Spoof");
      logger.warn({ pressureDiff, devicePressure: input.devicePressure, stationPressure: input.stationPressure }, "Potential altitude spoofing detected");
    } else if (pressureDiff > PRESSURE_TOLERANCE) {
      fraudScore += 15;
      fraudFlags.push("Pressure Mismatch");
    }
  }

  if (input.mockLocationDetected === true) {
    fraudScore += 40;
    fraudFlags.push("Mock Location");
    logger.warn("Mock location flag detected on claim");
  }

  if (input.systemIntegrityFlag) {
    const flag = input.systemIntegrityFlag.toLowerCase();
    if (flag.includes("root") || flag.includes("jailbreak")) {
      fraudScore += 25;
      fraudFlags.push("Root/Jailbreak");
    } else if (flag.includes("modified")) {
      fraudScore += 15;
      fraudFlags.push("Modified System");
    }
  }

  const isFlagged = fraudScore >= FRAUD_THRESHOLD;

  logger.info({ fraudScore, fraudFlags, isFlagged }, "FraudSentry analysis complete");

  return { fraudScore: Math.min(fraudScore, 100), fraudFlags, isFlagged };
}
