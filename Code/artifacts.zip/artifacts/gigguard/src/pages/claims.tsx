import { useState } from "react";
import { useListClaims, useVerifyClaimHandshake, useProcessClaimPayout, getListClaimsQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, AlertTriangle, CheckCircle2, Clock, ShieldAlert, Fingerprint } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

function getStatusBadge(status: string) {
  const map: Record<string, string> = {
    pending: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    approved: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    conditional_payout: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    paid: "bg-green-500/20 text-green-400 border-green-500/30",
    rejected: "bg-red-500/20 text-red-400 border-red-500/30",
  };
  return <Badge className={`text-xs ${map[status] ?? "bg-muted text-muted-foreground"}`}>{status.replace(/_/g, " ")}</Badge>;
}

function getFraudBadge(score: number) {
  if (score >= 61) return <Badge className="text-xs bg-red-500/20 text-red-400 border-red-500/30">Score: {score} — High</Badge>;
  if (score >= 31) return <Badge className="text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">Score: {score} — Medium</Badge>;
  return <Badge className="text-xs bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Score: {score} — Clean</Badge>;
}

export default function ClaimsPage() {
  const { data: claims, isLoading } = useListClaims();
  const verifyClaim = useVerifyClaimHandshake();
  const processPayout = useProcessClaimPayout();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [verifyDialog, setVerifyDialog] = useState<{ open: boolean; claimId: number | null }>({ open: false, claimId: null });
  const [handshakeInput, setHandshakeInput] = useState("");
  const [payoutDialog, setPayoutDialog] = useState<{ open: boolean; claimId: number | null }>({ open: false, claimId: null });

  const handleVerify = () => {
    if (!verifyDialog.claimId || !handshakeInput) return;
    verifyClaim.mutate({ id: verifyDialog.claimId, data: { handshakeCode: handshakeInput } }, {
      onSuccess: () => {
        toast({ title: "Claim verified!", description: "Digital handshake accepted. Payout is now approved." });
        queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
        setVerifyDialog({ open: false, claimId: null });
        setHandshakeInput("");
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Verification failed", description: err?.data?.error ?? "Invalid handshake code" });
      },
    });
  };

  const handlePayout = (choice: string) => {
    if (!payoutDialog.claimId) return;
    processPayout.mutate({ id: payoutDialog.claimId, data: { choice } }, {
      onSuccess: () => {
        toast({ title: "Payout processed!", description: choice === "vault" ? "Funds added to your Stability Vault." : "Funds withdrawn immediately." });
        queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
        setPayoutDialog({ open: false, claimId: null });
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Payout failed", description: err?.data?.error ?? "Could not process payout" });
      },
    });
  };

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Claims History</h1>
            <p className="text-muted-foreground text-sm mt-1">All your parametric insurance claims</p>
          </div>

          {isLoading ? (
            <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24" />)}</div>
          ) : !claims?.length ? (
            <Card>
              <CardContent className="py-16 text-center">
                <CheckCircle2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No claims yet. Claims are auto-triggered when weather or traffic thresholds are breached.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {claims.map((claim) => (
                <Card key={claim.id} className={claim.isFlagged ? "border-amber-500/30" : ""} data-testid={`claim-card-${claim.id}`}>
                  <CardContent className="pt-4 pb-4">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg mt-0.5 ${
                          claim.triggerType === "weather" ? "bg-blue-500/10" : "bg-amber-500/10"
                        }`}>
                          {claim.isFlagged
                            ? <ShieldAlert className="h-5 w-5 text-amber-400" />
                            : claim.triggerType === "weather"
                            ? <AlertTriangle className="h-5 w-5 text-blue-400" />
                            : <Clock className="h-5 w-5 text-amber-400" />
                          }
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-foreground capitalize">{claim.triggerType} trigger</span>
                            {getStatusBadge(claim.status)}
                            {claim.isFlagged && (
                              <Badge className="text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">FraudSentry Flagged</Badge>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Value: {claim.triggerValue.toFixed(1)} {claim.triggerType === "weather" ? "mm" : "min"} (threshold: {claim.triggerThreshold})
                          </div>
                          {claim.fraudFlags && claim.fraudFlags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {claim.fraudFlags.map((flag) => (
                                <Badge key={flag} className="text-xs bg-red-500/10 text-red-400 border-red-500/20">{flag}</Badge>
                              ))}
                            </div>
                          )}
                          <div className="text-xs text-muted-foreground mt-1">
                            {new Date(claim.createdAt).toLocaleString("en-IN")}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-2">
                        <div className="text-right">
                          <div className="text-xl font-bold text-foreground">₹{claim.payoutAmount}</div>
                          {getFraudBadge(claim.fraudScore)}
                        </div>

                        {claim.status === "conditional_payout" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-amber-500/40 text-amber-400 hover:bg-amber-500/10"
                            onClick={() => {
                              setVerifyDialog({ open: true, claimId: claim.id });
                              setHandshakeInput("");
                            }}
                            data-testid={`button-handshake-${claim.id}`}
                          >
                            <Fingerprint className="h-4 w-4 mr-1" />
                            Digital Handshake
                          </Button>
                        )}

                        {claim.status === "approved" && (
                          <Button
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-500 text-white"
                            onClick={() => setPayoutDialog({ open: true, claimId: claim.id })}
                            data-testid={`button-payout-${claim.id}`}
                          >
                            <CheckCircle2 className="h-4 w-4 mr-1" />
                            Claim Payout
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Digital Handshake Dialog */}
        <Dialog open={verifyDialog.open} onOpenChange={(v) => setVerifyDialog({ open: v, claimId: null })}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5 text-amber-400" />
                Digital Handshake Required
              </DialogTitle>
              <DialogDescription>
                This claim was flagged by FraudSentry. Enter the verification code to release your payout.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="p-4 rounded-lg border border-amber-500/30 bg-amber-500/5 font-mono text-center">
                <div className="text-xs text-muted-foreground mb-1">Your handshake code</div>
                <div className="text-lg font-bold text-amber-400 tracking-widest">
                  {claims?.find(c => c.id === verifyDialog.claimId)?.handshakeCode ?? "—"}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="handshake-input">Enter verification code</Label>
                <Input
                  id="handshake-input"
                  data-testid="input-handshake-code"
                  placeholder="e.g. A3F2B1C8"
                  value={handshakeInput}
                  onChange={(e) => setHandshakeInput(e.target.value.toUpperCase())}
                  className="font-mono tracking-widest"
                />
              </div>
              <Button
                className="w-full"
                onClick={handleVerify}
                disabled={verifyClaim.isPending || !handshakeInput}
                data-testid="button-submit-handshake"
              >
                {verifyClaim.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Verifying...</> : "Verify & Release Payout"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Payout Choice Dialog */}
        <Dialog open={payoutDialog.open} onOpenChange={(v) => setPayoutDialog({ open: v, claimId: null })}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Choose Your Payout Option</DialogTitle>
              <DialogDescription>
                Your claim has been approved. How would you like to receive your payout?
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 gap-3 pt-2">
              <Button
                variant="outline"
                className="h-auto p-4 justify-start border-emerald-500/30 hover:bg-emerald-500/10"
                onClick={() => handlePayout("withdraw")}
                disabled={processPayout.isPending}
                data-testid="button-payout-withdraw"
              >
                <div className="text-left">
                  <div className="font-semibold text-foreground">Withdraw Immediately</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Funds transferred to your UPI/bank account</div>
                </div>
              </Button>
              <Button
                variant="outline"
                className="h-auto p-4 justify-start border-primary/30 hover:bg-primary/10"
                onClick={() => handlePayout("vault")}
                disabled={processPayout.isPending}
                data-testid="button-payout-vault"
              >
                <div className="text-left">
                  <div className="font-semibold text-foreground">Reinvest in Vault</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Add to Stability Vault for future premiums or withdrawals</div>
                </div>
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </AppLayout>
    </ProtectedRoute>
  );
}
