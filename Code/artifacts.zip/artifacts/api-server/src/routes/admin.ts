import { Router, type IRouter } from "express";
import { db, workersTable, policiesTable, claimsTable, disruptionEventsTable } from "@workspace/db";
import { eq, gt, desc, sql } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";

const router: IRouter = Router();

function requireAdmin(req: AuthenticatedRequest, res: any, next: any): void {
  if (!req.workerId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

router.get("/admin/analytics", authMiddleware, requireAdmin, async (req: AuthenticatedRequest, res): Promise<void> => {
  const allWorkers = await db.select().from(workersTable);
  const allPolicies = await db.select().from(policiesTable);
  const allClaims = await db.select().from(claimsTable);

  const now = new Date();
  const activePolicies = allPolicies.filter(p => p.status === "active" && p.endDate > now).length;
  const totalPremiums = allPolicies.reduce((sum, p) => sum + p.premiumAmount, 0);
  const totalPayouts = allClaims.filter(c => c.status === "paid").reduce((sum, c) => sum + c.payoutAmount, 0);
  const lossRatio = totalPremiums > 0 ? (totalPayouts / totalPremiums) * 100 : 0;
  const pendingClaims = allClaims.filter(c => c.status === "pending" || c.status === "conditional_payout").length;
  const flaggedClaims = allClaims.filter(c => c.isFlagged).length;

  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const claimsThisWeek = allClaims.filter(c => c.createdAt > oneWeekAgo).length;

  const avgFraudScore = allClaims.length > 0
    ? allClaims.reduce((sum, c) => sum + c.fraudScore, 0) / allClaims.length
    : 0;

  const cityMap = new Map<string, { workers: number; claims: number; premiums: number; payouts: number }>();

  for (const w of allWorkers) {
    if (!cityMap.has(w.city)) cityMap.set(w.city, { workers: 0, claims: 0, premiums: 0, payouts: 0 });
    cityMap.get(w.city)!.workers++;
  }

  for (const c of allClaims) {
    const worker = allWorkers.find(w => w.id === c.workerId);
    if (worker) {
      if (!cityMap.has(worker.city)) cityMap.set(worker.city, { workers: 0, claims: 0, premiums: 0, payouts: 0 });
      cityMap.get(worker.city)!.claims++;
      if (c.status === "paid") cityMap.get(worker.city)!.payouts += c.payoutAmount;
    }
  }

  for (const p of allPolicies) {
    const worker = allWorkers.find(w => w.id === p.workerId);
    if (worker) {
      if (cityMap.has(worker.city)) cityMap.get(worker.city)!.premiums += p.premiumAmount;
    }
  }

  const topCities = Array.from(cityMap.entries())
    .map(([city, stats]) => ({
      city,
      workers: stats.workers,
      claims: stats.claims,
      lossRatio: stats.premiums > 0 ? (stats.payouts / stats.premiums) * 100 : 0,
    }))
    .sort((a, b) => b.workers - a.workers)
    .slice(0, 5);

  res.json({
    totalWorkers: allWorkers.length,
    activePolicies,
    totalPremiumsCollected: totalPremiums,
    totalPayoutsIssued: totalPayouts,
    lossRatio: Math.round(lossRatio * 10) / 10,
    pendingClaims,
    flaggedClaims,
    claimsThisWeek,
    avgFraudScore: Math.round(avgFraudScore * 10) / 10,
    topCities,
  });
});

router.get("/admin/loss-ratio", authMiddleware, requireAdmin, async (_req, res): Promise<void> => {
  const allPolicies = await db.select().from(policiesTable);
  const allClaims = await db.select().from(claimsTable);

  const weekMap = new Map<string, { premiums: number; payouts: number; claims: number }>();

  for (const p of allPolicies) {
    const d = new Date(p.createdAt);
    const weekStart = new Date(d);
    weekStart.setDate(d.getDate() - d.getDay());
    const key = weekStart.toISOString().split("T")[0]!;
    if (!weekMap.has(key)) weekMap.set(key, { premiums: 0, payouts: 0, claims: 0 });
    weekMap.get(key)!.premiums += p.premiumAmount;
  }

  for (const c of allClaims.filter(c => c.status === "paid")) {
    const d = new Date(c.createdAt);
    const weekStart = new Date(d);
    weekStart.setDate(d.getDate() - d.getDay());
    const key = weekStart.toISOString().split("T")[0]!;
    if (!weekMap.has(key)) weekMap.set(key, { premiums: 0, payouts: 0, claims: 0 });
    weekMap.get(key)!.payouts += c.payoutAmount;
    weekMap.get(key)!.claims++;
  }

  const baseData = generateMockLossRatioHistory();

  const liveData = Array.from(weekMap.entries())
    .map(([week, stats]) => ({
      week,
      premiums: Math.round(stats.premiums),
      payouts: Math.round(stats.payouts),
      lossRatio: stats.premiums > 0 ? Math.round((stats.payouts / stats.premiums) * 1000) / 10 : 0,
      claims: stats.claims,
    }))
    .sort((a, b) => a.week.localeCompare(b.week));

  const result = liveData.length > 0 ? liveData : baseData;
  res.json(result);
});

function generateMockLossRatioHistory() {
  const weeks = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i * 7);
    const key = d.toISOString().split("T")[0]!;
    const premiums = Math.round(250 + Math.random() * 500);
    const payouts = Math.round(premiums * (0.3 + Math.random() * 0.5));
    weeks.push({
      week: key,
      premiums,
      payouts,
      lossRatio: Math.round((payouts / premiums) * 1000) / 10,
      claims: Math.round(1 + Math.random() * 8),
    });
  }
  return weeks;
}

router.get("/admin/disruptions", authMiddleware, requireAdmin, async (_req, res): Promise<void> => {
  const events = await db.select().from(disruptionEventsTable).orderBy(desc(disruptionEventsTable.timestamp)).limit(50);

  if (events.length === 0) {
    const mockDisruptions = generateMockDisruptions();
    res.json(mockDisruptions);
    return;
  }

  res.json(events);
});

function generateMockDisruptions() {
  const cities = [
    { city: "Mumbai", lat: 19.076, lon: 72.877 },
    { city: "Bengaluru", lat: 12.971, lon: 77.594 },
    { city: "Delhi", lat: 28.613, lon: 77.209 },
    { city: "Chennai", lat: 13.083, lon: 80.270 },
    { city: "Hyderabad", lat: 17.385, lon: 78.486 },
    { city: "Kolkata", lat: 22.572, lon: 88.363 },
    { city: "Pune", lat: 18.520, lon: 73.856 },
    { city: "Ahmedabad", lat: 23.022, lon: 72.572 },
  ];

  const types = ["weather", "traffic"];
  const severities = ["Low", "Medium", "High"];

  return cities.map((c, i) => ({
    id: i + 1,
    city: c.city,
    lat: c.lat,
    lon: c.lon,
    type: types[i % 2]!,
    severity: severities[i % 3]!,
    value: types[i % 2] === "weather" ? 5 + Math.round(Math.random() * 10 * 10) / 10 : 20 + Math.round(Math.random() * 40),
    affectedWorkers: Math.round(5 + Math.random() * 50),
    claimsTriggered: Math.round(1 + Math.random() * 15),
    timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 3600 * 1000),
  }));
}

router.get("/admin/workers", authMiddleware, requireAdmin, async (_req, res): Promise<void> => {
  const workers = await db.select().from(workersTable).orderBy(desc(workersTable.createdAt));
  const out = workers.map(w => ({
    id: w.id, name: w.name, email: w.email, phone: w.phone,
    platform: w.platform, city: w.city, lat: w.lat, lon: w.lon,
    riskScore: w.riskScore, isAdmin: w.isAdmin, createdAt: w.createdAt,
  }));
  res.json(out);
});

router.get("/admin/claims", authMiddleware, requireAdmin, async (_req, res): Promise<void> => {
  const claims = await db.select().from(claimsTable).orderBy(desc(claimsTable.createdAt));
  const allWorkers = await db.select().from(workersTable);
  const enriched = claims.map(c => {
    const worker = allWorkers.find(w => w.id === c.workerId);
    return { ...c, workerName: worker?.name ?? null, city: worker?.city ?? null };
  });
  res.json(enriched);
});

export default router;
