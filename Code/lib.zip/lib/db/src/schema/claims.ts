import { pgTable, text, serial, timestamp, real, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const claimsTable = pgTable("claims", {
  id: serial("id").primaryKey(),
  workerId: integer("worker_id").notNull(),
  policyId: integer("policy_id").notNull(),
  triggerType: text("trigger_type").notNull(),
  triggerValue: real("trigger_value").notNull(),
  triggerThreshold: real("trigger_threshold").notNull(),
  status: text("status").notNull().default("pending"),
  payoutAmount: real("payout_amount").notNull().default(0),
  fraudScore: real("fraud_score").notNull().default(0),
  fraudFlags: text("fraud_flags").array().notNull().default([]),
  isFlagged: boolean("is_flagged").notNull().default(false),
  payoutChoice: text("payout_choice"),
  handshakeCode: text("handshake_code"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertClaimSchema = createInsertSchema(claimsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertClaim = z.infer<typeof insertClaimSchema>;
export type Claim = typeof claimsTable.$inferSelect;
