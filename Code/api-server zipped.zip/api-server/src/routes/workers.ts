import { Router, type IRouter } from "express";
import { db, workersTable, policiesTable, claimsTable, vaultsTable } from "@workspace/db";
import { eq, desc, and, gt } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";
import { fetchWeatherData } from "../lib/weather-service";

const router: IRouter = Router();

router.get("/workers/me", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, req.workerId!));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const workerOut = {
    id: worker.id, name: worker.name, email: worker.email, phone: worker.phone,
    platform: worker.platform, city: worker.city, lat: worker.lat, lon: worker.lon,
    riskScore: worker.riskScore, isAdmin: worker.isAdmin, createdAt: worker.createdAt,
  };

  res.json(workerOut);
});

router.get("/workers/me/dashboard", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, req.workerId!));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const now = new Date();
  const [activePolicy] = await db.select().from(policiesTable).where(
    and(
      eq(policiesTable.workerId, worker.id),
      eq(policiesTable.status, "active"),
      gt(policiesTable.endDate, now)
    )
  ).orderBy(desc(policiesTable.createdAt)).limit(1);

  const [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.workerId, worker.id));

  const recentClaims = await db.select().from(claimsTable)
    .where(eq(claimsTable.workerId, worker.id))
    .orderBy(desc(claimsTable.createdAt))
    .limit(5);

  const allClaims = await db.select().from(claimsTable).where(eq(claimsTable.workerId, worker.id));
  const totalPayouts = allClaims.filter(c => c.status === "paid").reduce((sum, c) => sum + c.payoutAmount, 0);

  let riskLevel = "Low";
  if (worker.riskScore >= 1.2) riskLevel = "High";
  else if (worker.riskScore >= 1.0) riskLevel = "Medium";

  let currentWeather = null;
  try {
    currentWeather = await fetchWeatherData(worker.lat, worker.lon);
  } catch {}

  const claimsOut = recentClaims.map(c => ({
    id: c.id, workerId: c.workerId, policyId: c.policyId, triggerType: c.triggerType,
    triggerValue: c.triggerValue, triggerThreshold: c.triggerThreshold, status: c.status,
    payoutAmount: c.payoutAmount, fraudScore: c.fraudScore, fraudFlags: c.fraudFlags,
    isFlagged: c.isFlagged, payoutChoice: c.payoutChoice, handshakeCode: c.handshakeCode,
    verifiedAt: c.verifiedAt, createdAt: c.createdAt, updatedAt: c.updatedAt,
    workerName: null, city: null,
  }));

  res.json({
    worker: {
      id: worker.id, name: worker.name, email: worker.email, phone: worker.phone,
      platform: worker.platform, city: worker.city, lat: worker.lat, lon: worker.lon,
      riskScore: worker.riskScore, isAdmin: worker.isAdmin, createdAt: worker.createdAt,
    },
    activePolicy: activePolicy ?? null,
    vault: vault ?? { id: 0, workerId: worker.id, balance: 0, totalDeposited: 0, totalWithdrawn: 0, updatedAt: new Date() },
    recentClaims: claimsOut,
    currentRiskLevel: riskLevel,
    premiumThisWeek: activePolicy?.premiumAmount ?? 0,
    totalPayoutsReceived: totalPayouts,
    currentWeather,
  });
});

export default router;
