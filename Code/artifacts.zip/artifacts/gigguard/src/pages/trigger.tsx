import { useState } from "react";
import { useCheckParametricTriggers, useGetCurrentWeather, getListClaimsQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Zap, CloudRain, Wind, Thermometer, Clock, AlertTriangle, CheckCircle2, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function TriggerPage() {
  const { worker } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [triggerResult, setTriggerResult] = useState<any>(null);
  const checkTriggers = useCheckParametricTriggers();

  const { data: weather, isLoading: weatherLoading } = useGetCurrentWeather(
    { lat: worker?.lat ?? 19.076, lon: worker?.lon ?? 72.877 },
    { query: { enabled: !!worker } as any }
  );

  const handleTriggerCheck = () => {
    if (!worker) return;
    checkTriggers.mutate({
      data: { workerId: worker.id, lat: worker.lat, lon: worker.lon }
    }, {
      onSuccess: (result) => {
        setTriggerResult(result);
        if (result.triggered) {
          queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
          toast({
            title: result.claimCreated ? "Claim auto-triggered!" : "Trigger detected",
            description: result.message,
          });
        } else {
          toast({ title: "No triggers detected", description: result.message });
        }
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Check failed", description: err?.data?.error ?? "Could not run trigger check" });
      },
    });
  };

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Trigger Check</h1>
            <p className="text-muted-foreground text-sm mt-1">Run parametric trigger analysis for your current location</p>
          </div>

          {/* Location Info */}
          <Card>
            <CardContent className="pt-5 pb-5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{worker?.city}</div>
                  <div className="text-xs text-muted-foreground">
                    {worker?.lat?.toFixed(3)}, {worker?.lon?.toFixed(3)} · {worker?.platform}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Conditions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <CloudRain className="h-4 w-4 text-blue-400" />
                  Weather Conditions
                </CardTitle>
              </CardHeader>
              <CardContent>
                {weatherLoading ? (
                  <div className="flex items-center justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : weather ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground flex items-center gap-1.5"><CloudRain className="h-3.5 w-3.5" />Rainfall</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-foreground">{(weather as any).rainfall?.toFixed(1)} mm</span>
                        {(weather as any).rainfall > 5 && <Badge className="bg-red-500/20 text-red-400 text-xs border-red-500/30">Above 5mm threshold</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground flex items-center gap-1.5"><Thermometer className="h-3.5 w-3.5" />Temperature</span>
                      <span className="font-bold text-foreground">{(weather as any).temperature?.toFixed(0)}°C</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground flex items-center gap-1.5"><Wind className="h-3.5 w-3.5" />Wind Speed</span>
                      <span className="font-bold text-foreground">{(weather as any).windSpeed?.toFixed(0)} km/h</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Condition</span>
                      <span className="font-medium text-foreground capitalize">{(weather as any).condition}</span>
                    </div>
                    <div className="pt-2 mt-2 border-t border-border">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>Trigger threshold: {">"}5mm rainfall</span>
                        {(weather as any).rainfall > 5 ? (
                          <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">THRESHOLD BREACHED</Badge>
                        ) : (
                          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">Below threshold</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ) : null}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <Clock className="h-4 w-4 text-amber-400" />
                  Traffic Conditions
                </CardTitle>
              </CardHeader>
              <CardContent>
                {triggerResult?.trafficData ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Delay</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-foreground">{triggerResult.trafficData.delayMinutes} min</span>
                        {triggerResult.trafficData.delayMinutes > 20 && (
                          <Badge className="bg-red-500/20 text-red-400 text-xs border-red-500/30">Above 20min threshold</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Congestion Level</span>
                      <span className="font-bold text-foreground">{triggerResult.trafficData.congestionLevel}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Affected Routes</span>
                      <span className="font-bold text-foreground">{triggerResult.trafficData.affectedRoutes}</span>
                    </div>
                    {triggerResult.trafficData.incident && (
                      <div className="p-2 rounded bg-amber-500/10 text-xs text-amber-400 border border-amber-500/20">
                        {triggerResult.trafficData.incident}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="py-6 text-center text-muted-foreground text-sm">
                    Run a trigger check to see traffic data
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Trigger Check Button */}
          <Card className="border-primary/30">
            <CardContent className="pt-6 pb-6 text-center">
              <div className="mb-4">
                <Zap className="h-10 w-10 text-primary mx-auto mb-2" />
                <h3 className="font-bold text-lg text-foreground">Run Parametric Trigger Check</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Analyzes your current weather and traffic conditions against thresholds. If triggered and you have an active policy, a claim will be created automatically.
                </p>
              </div>
              <Button
                size="lg"
                className="px-8"
                onClick={handleTriggerCheck}
                disabled={checkTriggers.isPending || !worker}
                data-testid="button-run-trigger-check"
              >
                {checkTriggers.isPending ? (
                  <><Loader2 className="mr-2 h-5 w-5 animate-spin" />Analyzing...</>
                ) : (
                  <><Zap className="mr-2 h-5 w-5" />Run Trigger Check</>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Result */}
          {triggerResult && (
            <Alert className={triggerResult.triggered ? "border-amber-500/40 bg-amber-500/5" : "border-emerald-500/40 bg-emerald-500/5"}>
              <div className="flex items-start gap-2">
                {triggerResult.triggered
                  ? <AlertTriangle className="h-5 w-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  : <CheckCircle2 className="h-5 w-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                }
                <AlertDescription className="text-foreground">
                  <div className="font-semibold mb-1">{triggerResult.triggered ? "Trigger Activated" : "All Clear"}</div>
                  <div className="text-sm">{triggerResult.message}</div>
                  {triggerResult.claimCreated && (
                    <div className="mt-2 text-xs text-muted-foreground">Claim #{triggerResult.claimId} created. Check Claims page to process your payout.</div>
                  )}
                </AlertDescription>
              </div>
            </Alert>
          )}

          {/* Threshold Reference */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest">Trigger Thresholds</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-muted/40">
                  <div className="flex items-center gap-2 mb-1">
                    <CloudRain className="h-4 w-4 text-blue-400" />
                    <span className="text-sm font-medium text-foreground">Weather Trigger</span>
                  </div>
                  <div className="text-xs text-muted-foreground">Rainfall {">"}5mm per hour triggers automatic claim</div>
                </div>
                <div className="p-3 rounded-lg bg-muted/40">
                  <div className="flex items-center gap-2 mb-1">
                    <Clock className="h-4 w-4 text-amber-400" />
                    <span className="text-sm font-medium text-foreground">Traffic Trigger</span>
                  </div>
                  <div className="text-xs text-muted-foreground">Delay {">"}20 minutes triggers automatic claim</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    </ProtectedRoute>
  );
}
