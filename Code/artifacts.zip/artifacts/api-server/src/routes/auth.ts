import { Router, type IRouter } from "express";
import { db, workersTable, vaultsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword, generateToken } from "../lib/auth";
import { RegisterWorkerBody, LoginWorkerBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterWorkerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { name, email, phone, platform, city, lat, lon, password } = parsed.data;

  const existing = await db.select().from(workersTable).where(eq(workersTable.email, email));
  if (existing.length > 0) {
    res.status(400).json({ error: "Email already registered" });
    return;
  }

  const passwordHash = await hashPassword(password);

  const [worker] = await db.insert(workersTable).values({
    name, email, phone, platform, city, lat, lon,
    passwordHash,
    riskScore: 1.0,
    isAdmin: false,
  }).returning();

  if (!worker) {
    res.status(500).json({ error: "Failed to create worker" });
    return;
  }

  await db.insert(vaultsTable).values({
    workerId: worker.id,
    balance: 0,
    totalDeposited: 0,
    totalWithdrawn: 0,
  });

  const token = generateToken(worker.id);

  const workerOut = {
    id: worker.id, name: worker.name, email: worker.email, phone: worker.phone,
    platform: worker.platform, city: worker.city, lat: worker.lat, lon: worker.lon,
    riskScore: worker.riskScore, isAdmin: worker.isAdmin, createdAt: worker.createdAt,
  };

  res.status(201).json({ token, worker: workerOut });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginWorkerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;

  const [worker] = await db.select().from(workersTable).where(eq(workersTable.email, email));
  if (!worker) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await verifyPassword(password, worker.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = generateToken(worker.id);

  const workerOut = {
    id: worker.id, name: worker.name, email: worker.email, phone: worker.phone,
    platform: worker.platform, city: worker.city, lat: worker.lat, lon: worker.lon,
    riskScore: worker.riskScore, isAdmin: worker.isAdmin, createdAt: worker.createdAt,
  };

  res.json({ token, worker: workerOut });
});

export default router;
