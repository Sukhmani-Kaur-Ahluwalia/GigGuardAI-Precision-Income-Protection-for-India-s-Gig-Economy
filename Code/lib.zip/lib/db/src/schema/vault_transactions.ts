import { pgTable, text, serial, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const vaultTransactionsTable = pgTable("vault_transactions", {
  id: serial("id").primaryKey(),
  vaultId: integer("vault_id").notNull(),
  type: text("type").notNull(),
  amount: real("amount").notNull(),
  description: text("description"),
  balanceAfter: real("balance_after").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVaultTransactionSchema = createInsertSchema(vaultTransactionsTable).omit({ id: true, createdAt: true });
export type InsertVaultTransaction = z.infer<typeof insertVaultTransactionSchema>;
export type VaultTransaction = typeof vaultTransactionsTable.$inferSelect;
