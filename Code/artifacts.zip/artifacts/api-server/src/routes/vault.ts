import { Router, type IRouter } from "express";
import { db, vaultsTable, vaultTransactionsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";
import { DepositToVaultBody, WithdrawFromVaultBody } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/vault", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.workerId, req.workerId!));
  if (!vault) {
    const [newVault] = await db.insert(vaultsTable).values({
      workerId: req.workerId!, balance: 0, totalDeposited: 0, totalWithdrawn: 0,
    }).returning();
    res.json(newVault);
    return;
  }
  res.json(vault);
});

router.post("/vault/deposit", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = DepositToVaultBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { amount, description } = parsed.data;

  let [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.workerId, req.workerId!));
  if (!vault) {
    [vault] = await db.insert(vaultsTable).values({
      workerId: req.workerId!, balance: 0, totalDeposited: 0, totalWithdrawn: 0,
    }).returning() as typeof vault[];
  }

  const newBalance = (vault!.balance ?? 0) + amount;
  const [updated] = await db.update(vaultsTable).set({
    balance: newBalance,
    totalDeposited: (vault!.totalDeposited ?? 0) + amount,
  }).where(eq(vaultsTable.workerId, req.workerId!)).returning();

  await db.insert(vaultTransactionsTable).values({
    vaultId: vault!.id,
    type: "deposit",
    amount,
    description: description ?? "Manual deposit",
    balanceAfter: newBalance,
  });

  res.json(updated);
});

router.post("/vault/withdraw", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = WithdrawFromVaultBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { amount, description } = parsed.data;

  const [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.workerId, req.workerId!));
  if (!vault || vault.balance < amount) {
    res.status(400).json({ error: "Insufficient vault balance" });
    return;
  }

  const newBalance = vault.balance - amount;
  const [updated] = await db.update(vaultsTable).set({
    balance: newBalance,
    totalWithdrawn: (vault.totalWithdrawn ?? 0) + amount,
  }).where(eq(vaultsTable.workerId, req.workerId!)).returning();

  await db.insert(vaultTransactionsTable).values({
    vaultId: vault.id,
    type: "withdrawal",
    amount,
    description: description ?? "Manual withdrawal",
    balanceAfter: newBalance,
  });

  res.json(updated);
});

router.get("/vault/transactions", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const [vault] = await db.select().from(vaultsTable).where(eq(vaultsTable.workerId, req.workerId!));
  if (!vault) {
    res.json([]);
    return;
  }

  const txns = await db.select().from(vaultTransactionsTable)
    .where(eq(vaultTransactionsTable.vaultId, vault.id))
    .orderBy(desc(vaultTransactionsTable.createdAt));
  res.json(txns);
});

export default router;
