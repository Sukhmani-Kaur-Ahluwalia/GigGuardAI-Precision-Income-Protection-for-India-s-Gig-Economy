import { Link, useLocation } from "wouter";
import { 
  ShieldCheck, 
  LayoutDashboard, 
  FileText, 
  ListChecks, 
  Zap, 
  Wallet, 
  BarChart3,
  LogOut,
  Menu
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { worker, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "My Policy", href: "/policy", icon: ShieldCheck },
    { name: "Claims", href: "/claims", icon: ListChecks },
    { name: "Trigger Check", href: "/trigger", icon: Zap },
    { name: "Stability Vault", href: "/vault", icon: Wallet },
  ];

  if (worker?.isAdmin) {
    navigation.push({ name: "Admin Analytics", href: "/admin", icon: BarChart3 });
  }

  const NavLinks = () => (
    <nav className="space-y-1">
      {navigation.map((item) => {
        const isActive = location === item.href;
        return (
          <Link key={item.name} href={item.href}>
            <div
              className={`flex items-center px-4 py-3 text-sm font-medium rounded-md cursor-pointer transition-colors ${
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
              onClick={() => setOpen(false)}
            >
              <item.icon className="mr-3 h-5 w-5" />
              {item.name}
            </div>
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg text-foreground">GigGuard AI</span>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-foreground">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="bg-card border-r-border w-64 p-0">
            <div className="p-4 border-b border-border flex items-center space-x-2">
              <ShieldCheck className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg text-foreground">GigGuard AI</span>
            </div>
            <div className="p-4">
              <NavLinks />
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border bg-card">
              <div className="flex items-center mb-4">
                <Avatar className="h-10 w-10 border border-border">
                  <AvatarFallback className="bg-muted text-foreground">
                    {worker?.name?.charAt(0) || "W"}
                  </AvatarFallback>
                </Avatar>
                <div className="ml-3 flex-1 overflow-hidden">
                  <p className="text-sm font-medium text-foreground truncate">{worker?.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{worker?.email}</p>
                </div>
              </div>
              <Button 
                variant="destructive" 
                className="w-full justify-start" 
                onClick={() => {
                  logout();
                  setLocation("/login");
                }}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 flex-col fixed inset-y-0 left-0 bg-sidebar border-r border-border">
        <div className="p-6 border-b border-border flex items-center space-x-3">
          <ShieldCheck className="h-8 w-8 text-primary" />
          <span className="font-bold text-xl tracking-tight text-sidebar-foreground">GigGuard AI</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <NavLinks />
        </div>
        <div className="p-4 border-t border-border bg-sidebar">
          <div className="flex items-center mb-4">
            <Avatar className="h-10 w-10 border border-border">
              <AvatarFallback className="bg-sidebar-accent text-sidebar-foreground">
                {worker?.name?.charAt(0) || "W"}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3 flex-1 overflow-hidden">
              <p className="text-sm font-medium text-sidebar-foreground truncate">{worker?.name}</p>
              <p className="text-xs text-muted-foreground truncate">{worker?.platform}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10" 
            onClick={() => {
              logout();
              setLocation("/login");
            }}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 md:pl-64 flex flex-col min-h-screen">
        <main className="flex-1 p-4 md:p-8 overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
