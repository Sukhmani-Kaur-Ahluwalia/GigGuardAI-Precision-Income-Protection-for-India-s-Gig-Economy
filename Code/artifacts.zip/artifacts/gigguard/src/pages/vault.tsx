import { useState } from "react";
import { useGetVault, useDepositToVault, useWithdrawFromVault, useListVaultTransactions, getGetVaultQueryKey, getListVaultTransactionsQueryKey } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet, ArrowDownCircle, ArrowUpCircle, TrendingUp, TrendingDown, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

function getTxBadge(type: string) {
  const map: Record<string, string> = {
    deposit: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    withdrawal: "bg-red-500/20 text-red-400 border-red-500/30",
    premium_payment: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    payout: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  };
  return <Badge className={`text-xs ${map[type] ?? "bg-muted text-muted-foreground"}`}>{type.replace(/_/g, " ")}</Badge>;
}

export default function VaultPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: vault, isLoading: vaultLoading } = useGetVault();
  const { data: transactions, isLoading: txLoading } = useListVaultTransactions();
  const deposit = useDepositToVault();
  const withdraw = useWithdrawFromVault();

  const [depositAmt, setDepositAmt] = useState("");
  const [withdrawAmt, setWithdrawAmt] = useState("");

  const handleDeposit = () => {
    const amount = parseFloat(depositAmt);
    if (isNaN(amount) || amount <= 0) return;
    deposit.mutate({ data: { amount, description: "Manual deposit" } }, {
      onSuccess: () => {
        toast({ title: "Deposited!", description: `₹${amount} added to your Stability Vault.` });
        queryClient.invalidateQueries({ queryKey: getGetVaultQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListVaultTransactionsQueryKey() });
        setDepositAmt("");
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Deposit failed", description: err?.data?.error ?? "Could not process deposit" });
      },
    });
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmt);
    if (isNaN(amount) || amount <= 0) return;
    withdraw.mutate({ data: { amount, description: "Manual withdrawal" } }, {
      onSuccess: () => {
        toast({ title: "Withdrawn!", description: `₹${amount} withdrawn from your Stability Vault.` });
        queryClient.invalidateQueries({ queryKey: getGetVaultQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListVaultTransactionsQueryKey() });
        setWithdrawAmt("");
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Withdrawal failed", description: err?.data?.error ?? "Insufficient balance or error" });
      },
    });
  };

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Stability Vault</h1>
            <p className="text-muted-foreground text-sm mt-1">Your liquid micro-savings for gig income resilience</p>
          </div>

          {/* Vault Balance */}
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-6 pb-6">
              {vaultLoading ? (
                <Skeleton className="h-20" />
              ) : (
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="p-4 rounded-xl bg-primary/20">
                      <Wallet className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Available Balance</div>
                      <div className="text-4xl font-bold text-foreground" data-testid="text-vault-balance">₹{vault?.balance?.toFixed(2) ?? "0.00"}</div>
                    </div>
                  </div>
                  <div className="flex gap-6">
                    <div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1.5 mb-0.5">
                        <TrendingUp className="h-3 w-3 text-emerald-400" /> Total Deposited
                      </div>
                      <div className="font-bold text-foreground">₹{vault?.totalDeposited?.toFixed(0) ?? 0}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1.5 mb-0.5">
                        <TrendingDown className="h-3 w-3 text-red-400" /> Total Withdrawn
                      </div>
                      <div className="font-bold text-foreground">₹{vault?.totalWithdrawn?.toFixed(0) ?? 0}</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <ArrowDownCircle className="h-4 w-4 text-emerald-400" />
                  Deposit
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="deposit-amount">Amount (₹)</Label>
                    <Input
                      id="deposit-amount"
                      data-testid="input-deposit-amount"
                      type="number"
                      placeholder="100"
                      value={depositAmt}
                      onChange={(e) => setDepositAmt(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {[50, 100, 250, 500].map((amt) => (
                      <Button key={amt} variant="outline" size="sm" onClick={() => setDepositAmt(String(amt))} className="text-xs">
                        ₹{amt}
                      </Button>
                    ))}
                  </div>
                  <Button
                    className="w-full"
                    onClick={handleDeposit}
                    disabled={deposit.isPending || !depositAmt}
                    data-testid="button-deposit"
                  >
                    {deposit.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Processing...</> : "Deposit to Vault"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <ArrowUpCircle className="h-4 w-4 text-red-400" />
                  Withdraw
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="withdraw-amount">Amount (₹)</Label>
                    <Input
                      id="withdraw-amount"
                      data-testid="input-withdraw-amount"
                      type="number"
                      placeholder="50"
                      value={withdrawAmt}
                      onChange={(e) => setWithdrawAmt(e.target.value)}
                    />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Available: ₹{vault?.balance?.toFixed(0) ?? 0}
                  </div>
                  <Button
                    variant="outline"
                    className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10"
                    onClick={handleWithdraw}
                    disabled={withdraw.isPending || !withdrawAmt || (vault?.balance ?? 0) < parseFloat(withdrawAmt || "0")}
                    data-testid="button-withdraw"
                  >
                    {withdraw.isPending ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Processing...</> : "Withdraw from Vault"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transactions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest">Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              {txLoading ? (
                <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-14" />)}</div>
              ) : !transactions?.length ? (
                <div className="py-8 text-center text-muted-foreground text-sm">No transactions yet</div>
              ) : (
                <div className="space-y-2">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30" data-testid={`tx-row-${tx.id}`}>
                      <div className="flex items-center gap-3">
                        {tx.type === "deposit" || tx.type === "payout"
                          ? <ArrowDownCircle className="h-4 w-4 text-emerald-400" />
                          : <ArrowUpCircle className="h-4 w-4 text-red-400" />
                        }
                        <div>
                          <div className="flex items-center gap-2">
                            {getTxBadge(tx.type)}
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {tx.description ?? ""} · {new Date(tx.createdAt).toLocaleDateString("en-IN")}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-bold ${tx.type === "withdrawal" || tx.type === "premium_payment" ? "text-red-400" : "text-emerald-400"}`}>
                          {tx.type === "withdrawal" || tx.type === "premium_payment" ? "-" : "+"}₹{tx.amount}
                        </div>
                        <div className="text-xs text-muted-foreground">Balance: ₹{tx.balanceAfter}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    </ProtectedRoute>
  );
}
