import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import fs from "node:fs";
import path from "node:path";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();
const frontendDistDir = path.resolve(
  process.cwd(),
  "artifacts",
  "gigguard",
  "dist",
  "public",
);
const frontendIndexPath = path.join(frontendDistDir, "index.html");

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

if (fs.existsSync(frontendIndexPath)) {
  app.use(express.static(frontendDistDir));

  app.get(/^(?!\/api\/).*/, (_req, res) => {
    res.sendFile(frontendIndexPath);
  });
} else {
  logger.warn(
    { frontendIndexPath },
    "Frontend build not found, serving API routes only",
  );
}

export default app;
