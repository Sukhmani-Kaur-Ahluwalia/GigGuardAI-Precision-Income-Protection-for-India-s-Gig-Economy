import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import workersRouter from "./workers";
import policiesRouter from "./policies";
import claimsRouter from "./claims";
import vaultRouter from "./vault";
import triggersRouter from "./triggers";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(workersRouter);
router.use(policiesRouter);
router.use(claimsRouter);
router.use(vaultRouter);
router.use(triggersRouter);
router.use(adminRouter);

export default router;
