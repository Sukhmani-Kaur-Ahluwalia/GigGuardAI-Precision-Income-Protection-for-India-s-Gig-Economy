import { db } from "@workspace/db";
import { claimsTable } from "@workspace/db";
import { gte, and, eq } from "drizzle-orm";
import { logger } from "./logger";

const BASE_PREMIUM = 25;
const ADJUSTMENT = 5;
const WEATHER_THRESHOLD = 5;
const TRAFFIC_THRESHOLD = 20;

export interface PremiumCalculationResult {
  basePremium: number;
  adjustedPremium: number;
  riskMultiplier: number;
  historicalDisruptions: number;
  riskLevel: "Low" | "Medium" | "High";
  reasoning: string;
}

export async function calculateDynamicPremium(
  workerId: number,
  city: string
): Promise<PremiumCalculationResult> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const historicalClaims = await db
    .select()
    .from(claimsTable)
    .where(
      and(
        eq(claimsTable.workerId, workerId),
        gte(claimsTable.createdAt, thirtyDaysAgo)
      )
    );

  const disruptions = historicalClaims.length;
  let adjustedPremium = BASE_PREMIUM;
  let riskMultiplier = 1.0;
  let riskLevel: "Low" | "Medium" | "High" = "Low";
  let reasoning = `Base premium ₹${BASE_PREMIUM}.`;

  if (disruptions >= 3) {
    adjustedPremium = BASE_PREMIUM + ADJUSTMENT;
    riskMultiplier = 1.2;
    riskLevel = "High";
    reasoning += ` High disruption history (${disruptions} events in 30 days) in ${city} micro-grid. Premium increased by ₹${ADJUSTMENT}.`;
  } else if (disruptions >= 1) {
    adjustedPremium = BASE_PREMIUM;
    riskMultiplier = 1.0;
    riskLevel = "Medium";
    reasoning += ` Moderate disruption history (${disruptions} events in 30 days) in ${city}. Standard premium applies.`;
  } else {
    adjustedPremium = BASE_PREMIUM - ADJUSTMENT;
    riskMultiplier = 0.8;
    riskLevel = "Low";
    reasoning += ` Clean disruption history in ${city} micro-grid. Premium reduced by ₹${ADJUSTMENT} as reward.`;
    if (adjustedPremium < 20) adjustedPremium = 20;
  }

  logger.info({ workerId, city, disruptions, adjustedPremium }, "Dynamic premium calculated");

  return {
    basePremium: BASE_PREMIUM,
    adjustedPremium,
    riskMultiplier,
    historicalDisruptions: disruptions,
    riskLevel,
    reasoning,
  };
}

export { WEATHER_THRESHOLD, TRAFFIC_THRESHOLD };
