import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { useEffect } from "react";

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { token } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!token && !localStorage.getItem("gigguard_token")) {
      setLocation("/login");
    }
  }, [token, setLocation]);

  if (!token) return null;

  return <>{children}</>;
}
