import { pgTable, text, serial, timestamp, real, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const disruptionEventsTable = pgTable("disruption_events", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  lat: real("lat").notNull(),
  lon: real("lon").notNull(),
  type: text("type").notNull(),
  severity: text("severity").notNull(),
  value: real("value").notNull(),
  affectedWorkers: integer("affected_workers").notNull().default(0),
  claimsTriggered: integer("claims_triggered").notNull().default(0),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});

export const insertDisruptionEventSchema = createInsertSchema(disruptionEventsTable).omit({ id: true });
export type InsertDisruptionEvent = z.infer<typeof insertDisruptionEventSchema>;
export type DisruptionEvent = typeof disruptionEventsTable.$inferSelect;
