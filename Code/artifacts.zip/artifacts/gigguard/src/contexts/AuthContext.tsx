import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Worker } from "@workspace/api-client-react";

interface AuthContextType {
  token: string | null;
  worker: Worker | null;
  login: (token: string, worker: Worker) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [worker, setWorker] = useState<Worker | null>(null);

  useEffect(() => {
    const storedToken = localStorage.getItem("gigguard_token");
    const storedWorker = localStorage.getItem("gigguard_worker");
    if (storedToken && storedWorker) {
      setToken(storedToken);
      try {
        setWorker(JSON.parse(storedWorker));
      } catch (e) {
        console.error("Failed to parse stored worker", e);
      }
    }
  }, []);

  const login = (newToken: string, newWorker: Worker) => {
    localStorage.setItem("gigguard_token", newToken);
    localStorage.setItem("gigguard_worker", JSON.stringify(newWorker));
    setToken(newToken);
    setWorker(newWorker);
  };

  const logout = () => {
    localStorage.removeItem("gigguard_token");
    localStorage.removeItem("gigguard_worker");
    setToken(null);
    setWorker(null);
  };

  return (
    <AuthContext.Provider value={{ token, worker, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
