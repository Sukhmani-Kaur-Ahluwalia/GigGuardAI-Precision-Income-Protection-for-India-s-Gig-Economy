import { useState } from "react";
import { useListPolicies, useGetActivePolicy, useCreatePolicy, useCalculatePremium, getListPoliciesQueryKey, getGetActivePolicyQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldCheck, ShieldOff, Zap, CloudRain, Sun, AlertTriangle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

const SHIELD_TYPES = [
  { id: "Flood Shield", label: "Flood Shield", desc: "Covers income loss when rainfall exceeds 5mm/hr", icon: CloudRain, color: "text-blue-400" },
  { id: "Traffic Shield", label: "Traffic Shield", desc: "Covers income loss when traffic delay exceeds 20 mins", icon: Zap, color: "text-amber-400" },
  { id: "Heatwave Shield", label: "Heatwave Shield", desc: "Covers income loss during extreme heat events", icon: Sun, color: "text-orange-400" },
  { id: "All-Weather Shield", label: "All-Weather Shield", desc: "Comprehensive coverage for all parametric triggers", icon: ShieldCheck, color: "text-primary" },
];

export default function PolicyPage() {
  const { worker } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedShield, setSelectedShield] = useState<string | null>(null);

  const { data: policies, isLoading: policiesLoading } = useListPolicies();
  const { data: activePolicy } = useGetActivePolicy();
  const createPolicy = useCreatePolicy();
  const calcPremium = useCalculatePremium();

  const [premiumPreview, setPremiumPreview] = useState<{ adjustedPremium: number; riskLevel: string; reasoning: string } | null>(null);

  const handleSelectShield = (shieldId: string) => {
    setSelectedShield(shieldId);
    if (worker) {
      calcPremium.mutate({
        data: { workerId: worker.id, lat: worker.lat, lon: worker.lon, city: worker.city }
      }, {
        onSuccess: (result) => setPremiumPreview(result),
      });
    }
  };

  const handleActivate = () => {
    if (!selectedShield || !worker) return;
    createPolicy.mutate({ data: { shieldType: selectedShield, workerId: worker.id } }, {
      onSuccess: () => {
        toast({ title: "Shield activated!", description: `${selectedShield} is now active for this week.` });
        queryClient.invalidateQueries({ queryKey: getListPoliciesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetActivePolicyQueryKey() });
        setSelectedShield(null);
        setPremiumPreview(null);
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "Activation failed", description: err?.data?.error ?? "Could not activate shield" });
      },
    });
  };

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">My Policy</h1>
            <p className="text-muted-foreground text-sm mt-1">Manage your weekly parametric shield coverage</p>
          </div>

          {/* Active Policy Banner */}
          {activePolicy && (
            <Card className="border-primary/40 bg-primary/5">
              <CardContent className="pt-5 pb-5">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-primary/20">
                      <ShieldCheck className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-foreground">{activePolicy.shieldType}</span>
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">Active</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        ₹{activePolicy.premiumAmount}/week · Coverage ₹{activePolicy.coverageAmount} · Expires {new Date(activePolicy.endDate).toLocaleDateString("en-IN")}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    Shield is active and monitoring
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Shield Selection */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">Select a Shield</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SHIELD_TYPES.map(({ id, label, desc, icon: Icon, color }) => (
                <button
                  key={id}
                  data-testid={`shield-option-${id}`}
                  onClick={() => handleSelectShield(id)}
                  className={`text-left p-4 rounded-xl border transition-all ${
                    selectedShield === id
                      ? "border-primary bg-primary/10 ring-1 ring-primary"
                      : "border-border bg-card hover:border-primary/40"
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`p-2 rounded-lg bg-muted/50 ${color}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="font-semibold text-foreground">{label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Premium Preview */}
          {selectedShield && premiumPreview && (
            <Card className="border-amber-500/30 bg-amber-500/5">
              <CardContent className="pt-5 pb-5">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-foreground">Premium for {selectedShield}</span>
                      <span className="text-2xl font-bold text-foreground">₹{premiumPreview.adjustedPremium}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{premiumPreview.reasoning}</p>
                    <Badge className="mt-2 text-xs" variant="outline">
                      Risk Level: {premiumPreview.riskLevel}
                    </Badge>
                  </div>
                </div>
                <Button
                  className="w-full mt-4"
                  onClick={handleActivate}
                  disabled={createPolicy.isPending}
                  data-testid="button-activate-shield"
                >
                  {createPolicy.isPending ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Activating...</>
                  ) : (
                    <>Activate {selectedShield} — ₹{premiumPreview.adjustedPremium}</>
                  )}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Policy History */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">Policy History</h2>
            {policiesLoading ? (
              <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
            ) : !policies?.length ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <ShieldOff className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No policies yet. Activate your first shield above.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {policies.map((p) => (
                  <Card key={p.id} data-testid={`policy-row-${p.id}`}>
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-foreground text-sm">{p.shieldType}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(p.startDate).toLocaleDateString("en-IN")} — {new Date(p.endDate).toLocaleDateString("en-IN")}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-bold text-foreground">₹{p.premiumAmount}</div>
                          <Badge
                            className={`mt-1 text-xs ${
                              p.status === "active" ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                              : p.status === "expired" ? "bg-muted text-muted-foreground"
                              : "bg-red-500/20 text-red-400 border-red-500/30"
                            }`}
                          >
                            {p.status}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </AppLayout>
    </ProtectedRoute>
  );
}
