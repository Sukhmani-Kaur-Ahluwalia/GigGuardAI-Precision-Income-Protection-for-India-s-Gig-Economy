import { useGetWorkerDashboard } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShieldCheck, ShieldOff, Wallet, CloudRain, Wind, Thermometer, AlertTriangle, TrendingUp, Clock, CheckCircle2 } from "lucide-react";

function getRiskBadge(level: string) {
  if (level === "High") return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">High Risk</Badge>;
  if (level === "Medium") return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Medium Risk</Badge>;
  return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Low Risk</Badge>;
}

function getClaimStatusBadge(status: string) {
  const map: Record<string, string> = {
    pending: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    approved: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    conditional_payout: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    paid: "bg-green-500/20 text-green-400 border-green-500/30",
    rejected: "bg-red-500/20 text-red-400 border-red-500/30",
  };
  return <Badge className={map[status] ?? "bg-muted text-muted-foreground"}>{status.replace(/_/g, " ")}</Badge>;
}

export default function Dashboard() {
  const { worker } = useAuth();
  const { data: dashboard, isLoading } = useGetWorkerDashboard();

  if (isLoading) {
    return (
      <ProtectedRoute>
        <AppLayout>
          <div className="space-y-6">
            <Skeleton className="h-8 w-64" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}
            </div>
          </div>
        </AppLayout>
      </ProtectedRoute>
    );
  }

  const activePolicy = dashboard?.activePolicy;
  const vault = dashboard?.vault;
  const riskLevel = dashboard?.currentRiskLevel ?? "Low";
  const weather = dashboard?.currentWeather;
  const displayCity = worker?.city?.trim() || weather?.city || "Your City";

  if (weather) {
    weather.city = displayCity;
  }

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Welcome back, {worker?.name?.split(" ")[0]}
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              {worker?.platform} partner · {worker?.city}
            </p>
          </div>

          {/* Active Shield Hero */}
          <Card className={`border-2 relative overflow-hidden ${activePolicy ? "border-primary/50 bg-primary/5" : "border-border"}`}>
            <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
            <CardContent className="pt-6 pb-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${activePolicy ? "bg-primary/20" : "bg-muted"}`}>
                    {activePolicy
                      ? <ShieldCheck className="h-8 w-8 text-primary" data-testid="shield-active-icon" />
                      : <ShieldOff className="h-8 w-8 text-muted-foreground" data-testid="shield-inactive-icon" />
                    }
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h2 className="text-xl font-bold text-foreground">
                        {activePolicy ? activePolicy.shieldType : "No Active Shield"}
                      </h2>
                      {activePolicy && (
                        <span className="flex h-2.5 w-2.5 relative">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                        </span>
                      )}
                    </div>
                    {activePolicy ? (
                      <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                        <span>Coverage: <span className="text-foreground font-medium">₹{activePolicy.coverageAmount}</span></span>
                        <span>Premium: <span className="text-foreground font-medium">₹{activePolicy.premiumAmount}/week</span></span>
                        <span>Expires: <span className="text-foreground font-medium">{new Date(activePolicy.endDate).toLocaleDateString("en-IN")}</span></span>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">Activate a weekly shield to get parametric coverage</p>
                    )}
                  </div>
                </div>
                <div className="hidden md:block">
                  {getRiskBadge(riskLevel)}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card data-testid="card-vault-balance">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Stability Vault</span>
                  <Wallet className="h-4 w-4 text-primary" />
                </div>
                <div className="text-3xl font-bold text-foreground">₹{vault?.balance?.toFixed(0) ?? 0}</div>
                <p className="text-xs text-muted-foreground mt-1">Available balance</p>
              </CardContent>
            </Card>

            <Card data-testid="card-risk-level">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Risk Level</span>
                  <AlertTriangle className="h-4 w-4 text-amber-400" />
                </div>
                <div className="text-3xl font-bold text-foreground">{riskLevel}</div>
                <div className="mt-2">{getRiskBadge(riskLevel)}</div>
              </CardContent>
            </Card>

            <Card data-testid="card-premium">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Weekly Premium</span>
                  <TrendingUp className="h-4 w-4 text-emerald-400" />
                </div>
                <div className="text-3xl font-bold text-foreground">₹{dashboard?.premiumThisWeek ?? 0}</div>
                <p className="text-xs text-muted-foreground mt-1">This week's cost</p>
              </CardContent>
            </Card>

            <Card data-testid="card-total-payouts">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Total Received</span>
                  <CheckCircle2 className="h-4 w-4 text-green-400" />
                </div>
                <div className="text-3xl font-bold text-foreground">₹{dashboard?.totalPayoutsReceived?.toFixed(0) ?? 0}</div>
                <p className="text-xs text-muted-foreground mt-1">Lifetime payouts</p>
              </CardContent>
            </Card>
          </div>

          {/* Weather + Recent Claims */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {weather && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                    <CloudRain className="h-4 w-4 text-blue-400" />
                    Current Conditions — {weather.city}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <CloudRain className="h-4 w-4 text-blue-400" />
                        <span className="text-xs text-muted-foreground">Rainfall</span>
                      </div>
                      <div className="text-xl font-bold text-foreground">{weather.rainfall.toFixed(1)} mm</div>
                      {weather.rainfall > 5 && (
                        <Badge className="mt-1 text-xs bg-red-500/20 text-red-400 border-red-500/30">Above threshold</Badge>
                      )}
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Thermometer className="h-4 w-4 text-orange-400" />
                        <span className="text-xs text-muted-foreground">Temperature</span>
                      </div>
                      <div className="text-xl font-bold text-foreground">{weather.temperature.toFixed(0)}°C</div>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Wind className="h-4 w-4 text-cyan-400" />
                        <span className="text-xs text-muted-foreground">Wind</span>
                      </div>
                      <div className="text-xl font-bold text-foreground">{weather.windSpeed.toFixed(0)} km/h</div>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <span className="text-xs text-muted-foreground">Condition</span>
                      <div className="text-sm font-medium text-foreground capitalize mt-1">{weather.condition}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  Recent Claims
                </CardTitle>
              </CardHeader>
              <CardContent>
                {!dashboard?.recentClaims?.length ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">No claims yet</div>
                ) : (
                  <div className="space-y-3">
                    {dashboard.recentClaims.map((claim) => (
                      <div key={claim.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30" data-testid={`claim-row-${claim.id}`}>
                        <div>
                          <div className="text-sm font-medium text-foreground capitalize">{claim.triggerType} trigger</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(claim.createdAt).toLocaleDateString("en-IN")}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-bold text-foreground">₹{claim.payoutAmount}</div>
                          <div className="mt-1">{getClaimStatusBadge(claim.status)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </AppLayout>
    </ProtectedRoute>
  );
}
