import { useGetAdminAnalytics, useGetLossRatioHistory, useGetDisruptionMap, useListAllClaims } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Users, TrendingUp, AlertTriangle, BarChart3, MapPin, ShieldAlert } from "lucide-react";

function getClaimStatusBadge(status: string) {
  const map: Record<string, string> = {
    pending: "bg-blue-500/20 text-blue-400 border-blue-500/30",
    approved: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    conditional_payout: "bg-amber-500/20 text-amber-400 border-amber-500/30",
    paid: "bg-green-500/20 text-green-400 border-green-500/30",
    rejected: "bg-red-500/20 text-red-400 border-red-500/30",
  };
  return <Badge className={`text-xs ${map[status] ?? "bg-muted text-muted-foreground"}`}>{status.replace(/_/g, " ")}</Badge>;
}

function getSeverityBadge(severity: string) {
  if (severity === "High") return <Badge className="text-xs bg-red-500/20 text-red-400 border-red-500/30">High</Badge>;
  if (severity === "Medium") return <Badge className="text-xs bg-amber-500/20 text-amber-400 border-amber-500/30">Medium</Badge>;
  return <Badge className="text-xs bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Low</Badge>;
}

export default function AdminPage() {
  const { worker } = useAuth();

  const { data: analytics, isLoading: analyticsLoading } = useGetAdminAnalytics();
  const { data: lossRatio, isLoading: lrLoading } = useGetLossRatioHistory();
  const { data: disruptions, isLoading: disruptionsLoading } = useGetDisruptionMap();
  const { data: allClaims, isLoading: claimsLoading } = useListAllClaims();

  if (!worker?.isAdmin) {
    return (
      <ProtectedRoute>
        <AppLayout>
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <ShieldAlert className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <h2 className="text-lg font-semibold text-foreground">Admin Access Required</h2>
              <p className="text-muted-foreground text-sm">This page is only accessible to admin users.</p>
            </div>
          </div>
        </AppLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <AppLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Admin Analytics</h1>
            <p className="text-muted-foreground text-sm mt-1">Real-time platform oversight and loss analytics</p>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Card data-testid="card-total-workers">
              <CardContent className="pt-5 pb-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Workers</span>
                  <Users className="h-4 w-4 text-primary" />
                </div>
                {analyticsLoading ? <Skeleton className="h-8" /> : (
                  <div className="text-3xl font-bold text-foreground">{analytics?.totalWorkers ?? 0}</div>
                )}
              </CardContent>
            </Card>

            <Card data-testid="card-loss-ratio">
              <CardContent className="pt-5 pb-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Loss Ratio</span>
                  <TrendingUp className="h-4 w-4 text-amber-400" />
                </div>
                {analyticsLoading ? <Skeleton className="h-8" /> : (
                  <>
                    <div className="text-3xl font-bold text-foreground">{analytics?.lossRatio?.toFixed(1) ?? 0}%</div>
                    <div className="text-xs text-muted-foreground mt-1">Payouts / Premiums</div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card data-testid="card-flagged-claims">
              <CardContent className="pt-5 pb-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Flagged</span>
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                </div>
                {analyticsLoading ? <Skeleton className="h-8" /> : (
                  <>
                    <div className="text-3xl font-bold text-foreground">{analytics?.flaggedClaims ?? 0}</div>
                    <div className="text-xs text-muted-foreground mt-1">FraudSentry alerts</div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card data-testid="card-total-payouts-admin">
              <CardContent className="pt-5 pb-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Total Payouts</span>
                  <BarChart3 className="h-4 w-4 text-emerald-400" />
                </div>
                {analyticsLoading ? <Skeleton className="h-8" /> : (
                  <div className="text-3xl font-bold text-foreground">₹{analytics?.totalPayoutsIssued?.toFixed(0) ?? 0}</div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Loss Ratio Chart */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest">Loss Ratio — Weekly Trend</CardTitle>
            </CardHeader>
            <CardContent>
              {lrLoading ? (
                <Skeleton className="h-64" />
              ) : (
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={lossRatio ?? []} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="week" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                    <YAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                    <Tooltip
                      contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }}
                      labelStyle={{ color: "hsl(var(--foreground))" }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line type="monotone" dataKey="premiums" name="Premiums (₹)" stroke="#7c3aed" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="payouts" name="Payouts (₹)" stroke="#f59e0b" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="lossRatio" name="Loss Ratio (%)" stroke="#10b981" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Disruption Map + City Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-red-400" />
                  Live Disruption Map
                </CardTitle>
              </CardHeader>
              <CardContent>
                {disruptionsLoading ? (
                  <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-2 text-xs text-muted-foreground font-semibold">City</th>
                          <th className="text-left py-2 text-xs text-muted-foreground font-semibold">Type</th>
                          <th className="text-left py-2 text-xs text-muted-foreground font-semibold">Severity</th>
                          <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Claims</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(disruptions ?? []).slice(0, 8).map((d) => (
                          <tr key={d.id} className="border-b border-border/50" data-testid={`disruption-row-${d.id}`}>
                            <td className="py-2.5 font-medium text-foreground">{d.city}</td>
                            <td className="py-2.5 capitalize text-muted-foreground">{d.type}</td>
                            <td className="py-2.5">{getSeverityBadge(d.severity)}</td>
                            <td className="py-2.5 text-right font-bold text-foreground">{d.claimsTriggered}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest">City Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                {analyticsLoading ? (
                  <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-2 text-xs text-muted-foreground font-semibold">City</th>
                          <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Workers</th>
                          <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Claims</th>
                          <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Loss Ratio</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(analytics?.topCities ?? []).map((c) => (
                          <tr key={c.city} className="border-b border-border/50">
                            <td className="py-2.5 font-medium text-foreground">{c.city}</td>
                            <td className="py-2.5 text-right text-muted-foreground">{c.workers}</td>
                            <td className="py-2.5 text-right text-muted-foreground">{c.claims}</td>
                            <td className="py-2.5 text-right font-bold text-foreground">{c.lossRatio.toFixed(1)}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* All Claims Table */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-widest">All Claims</CardTitle>
            </CardHeader>
            <CardContent>
              {claimsLoading ? (
                <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm min-w-[600px]">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-2 text-xs text-muted-foreground font-semibold">Worker</th>
                        <th className="text-left py-2 text-xs text-muted-foreground font-semibold">City</th>
                        <th className="text-left py-2 text-xs text-muted-foreground font-semibold">Type</th>
                        <th className="text-left py-2 text-xs text-muted-foreground font-semibold">Status</th>
                        <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Fraud</th>
                        <th className="text-right py-2 text-xs text-muted-foreground font-semibold">Payout</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(allClaims ?? []).map((c) => (
                        <tr key={c.id} className="border-b border-border/50" data-testid={`admin-claim-row-${c.id}`}>
                          <td className="py-2.5 font-medium text-foreground">{c.workerName ?? `Worker #${c.workerId}`}</td>
                          <td className="py-2.5 text-muted-foreground">{c.city ?? "—"}</td>
                          <td className="py-2.5 capitalize text-muted-foreground">{c.triggerType}</td>
                          <td className="py-2.5">{getClaimStatusBadge(c.status)}</td>
                          <td className="py-2.5 text-right">
                            <Badge className={`text-xs ${
                              c.fraudScore >= 61 ? "bg-red-500/20 text-red-400 border-red-500/30"
                              : c.fraudScore >= 31 ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
                              : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                            }`}>
                              {c.fraudScore}
                            </Badge>
                          </td>
                          <td className="py-2.5 text-right font-bold text-foreground">₹{c.payoutAmount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    </ProtectedRoute>
  );
}
