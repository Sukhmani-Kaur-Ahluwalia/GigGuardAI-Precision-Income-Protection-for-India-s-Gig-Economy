import { logger } from "./logger";

export interface WeatherData {
  rainfall: number;
  temperature: number;
  windSpeed: number;
  humidity: number;
  condition: string;
  pressure: number;
  city: string;
  timestamp: Date;
}

export interface TrafficData {
  delayMinutes: number;
  congestionLevel: string;
  affectedRoutes: number;
  incident: string | null;
  timestamp: Date;
}

const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY;
const WEATHER_THRESHOLD = 5;
const TRAFFIC_THRESHOLD = 20;

export async function fetchWeatherData(lat: number, lon: number): Promise<WeatherData> {
  if (OPENWEATHER_API_KEY) {
    try {
      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json() as {
          rain?: { "1h"?: number };
          main: { temp: number; humidity: number; pressure: number };
          wind: { speed: number };
          weather: Array<{ description: string }>;
          name: string;
        };
        return {
          rainfall: data.rain?.["1h"] ?? 0,
          temperature: data.main.temp,
          windSpeed: data.wind.speed,
          humidity: data.main.humidity,
          condition: data.weather[0]?.description ?? "clear",
          pressure: data.main.pressure,
          city: data.name,
          timestamp: new Date(),
        };
      }
    } catch (err) {
      logger.warn({ err }, "OpenWeatherMap API call failed, using mock data");
    }
  }

  return getMockWeatherData(lat, lon);
}

function getMockWeatherData(lat: number, lon: number): WeatherData {
  const cities: Record<string, string> = {
    "19": "Mumbai",
    "12": "Bengaluru",
    "13": "Chennai",
    "28": "Delhi",
    "17": "Hyderabad",
    "22": "Kolkata",
  };

  const latKey = String(Math.round(lat));
  const city = cities[latKey] ?? "Mumbai";

  const scenarios = [
    { rainfall: 0.2, temp: 32, wind: 8, humidity: 65, condition: "partly cloudy", pressure: 1013 },
    { rainfall: 6.5, temp: 26, wind: 18, humidity: 90, condition: "heavy rain", pressure: 1005 },
    { rainfall: 2.1, temp: 28, wind: 12, humidity: 78, condition: "light rain", pressure: 1009 },
    { rainfall: 0, temp: 35, wind: 5, humidity: 55, condition: "clear sky", pressure: 1015 },
    { rainfall: 8.3, temp: 24, wind: 22, humidity: 95, condition: "thunderstorm", pressure: 1002 },
  ];

  const idx = Math.floor(Math.abs(lat * lon * 7.3)) % scenarios.length;
  const scenario = scenarios[idx]!;

  return {
    rainfall: scenario.rainfall,
    temperature: scenario.temp,
    windSpeed: scenario.wind,
    humidity: scenario.humidity,
    condition: scenario.condition,
    pressure: scenario.pressure,
    city,
    timestamp: new Date(),
  };
}

export function getMockTrafficData(lat: number, lon: number): TrafficData {
  const scenarios = [
    { delay: 5, congestion: "Low", routes: 0, incident: null },
    { delay: 25, congestion: "High", routes: 3, incident: "Waterlogging on NH-8" },
    { delay: 15, congestion: "Medium", routes: 2, incident: "Road closure near market" },
    { delay: 35, congestion: "Severe", routes: 5, incident: "Flash flood reported" },
    { delay: 8, congestion: "Low", routes: 1, incident: null },
  ];

  const idx = Math.floor(Math.abs(lat * lon * 3.7)) % scenarios.length;
  const s = scenarios[idx]!;

  return {
    delayMinutes: s.delay,
    congestionLevel: s.congestion,
    affectedRoutes: s.routes,
    incident: s.incident,
    timestamp: new Date(),
  };
}

export { WEATHER_THRESHOLD, TRAFFIC_THRESHOLD };
