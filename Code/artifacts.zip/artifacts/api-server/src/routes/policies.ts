import { Router, type IRouter } from "express";
import { db, policiesTable, workersTable } from "@workspace/db";
import { eq, and, gt, desc } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";
import { CreatePolicyBody, GetPolicyParams, CalculatePremiumBody } from "@workspace/api-zod";
import { calculateDynamicPremium } from "../lib/pricing-service";

const router: IRouter = Router();

router.get("/policies", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const policies = await db.select().from(policiesTable)
    .where(eq(policiesTable.workerId, req.workerId!))
    .orderBy(desc(policiesTable.createdAt));
  res.json(policies);
});

router.post("/policies", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = CreatePolicyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const workerId = parsed.data.workerId ?? req.workerId!;
  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, workerId));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const existingActive = await db.select().from(policiesTable).where(
    and(eq(policiesTable.workerId, workerId), eq(policiesTable.status, "active"), gt(policiesTable.endDate, new Date()))
  );
  if (existingActive.length > 0) {
    await db.update(policiesTable).set({ status: "cancelled" }).where(eq(policiesTable.id, existingActive[0]!.id));
  }

  const { adjustedPremium } = await calculateDynamicPremium(workerId, worker.city);

  const startDate = new Date();
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + 7);

  const [policy] = await db.insert(policiesTable).values({
    workerId,
    shieldType: parsed.data.shieldType,
    status: "active",
    premiumAmount: adjustedPremium,
    coverageAmount: 500,
    startDate,
    endDate,
  }).returning();

  res.status(201).json(policy);
});

router.get("/policies/active", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const now = new Date();
  const [policy] = await db.select().from(policiesTable).where(
    and(
      eq(policiesTable.workerId, req.workerId!),
      eq(policiesTable.status, "active"),
      gt(policiesTable.endDate, now)
    )
  ).orderBy(desc(policiesTable.createdAt)).limit(1);

  if (!policy) {
    res.status(404).json({ error: "No active policy found" });
    return;
  }

  res.json(policy);
});

router.get("/policies/:id", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const params = GetPolicyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [policy] = await db.select().from(policiesTable).where(eq(policiesTable.id, params.data.id));
  if (!policy) {
    res.status(404).json({ error: "Policy not found" });
    return;
  }

  res.json(policy);
});

router.post("/pricing/calculate", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = CalculatePremiumBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = await calculateDynamicPremium(parsed.data.workerId, parsed.data.city);
  res.json(result);
});

export default router;
