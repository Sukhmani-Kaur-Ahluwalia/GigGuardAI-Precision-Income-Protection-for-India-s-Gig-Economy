import { Router, type IRouter } from "express";
import { db, claimsTable, workersTable, policiesTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { authMiddleware, type AuthenticatedRequest } from "../lib/auth";
import { CreateClaimBody, GetClaimParams, VerifyClaimHandshakeParams, VerifyClaimHandshakeBody, ProcessClaimPayoutParams, ProcessClaimPayoutBody } from "@workspace/api-zod";
import { runFraudSentry } from "../lib/fraud-sentry";
import { fetchWeatherData } from "../lib/weather-service";
import { WEATHER_THRESHOLD, TRAFFIC_THRESHOLD } from "../lib/pricing-service";
import { randomBytes } from "crypto";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/claims", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const claims = await db.select().from(claimsTable)
    .where(eq(claimsTable.workerId, req.workerId!))
    .orderBy(desc(claimsTable.createdAt));

  const enriched = claims.map(c => ({ ...c, workerName: null, city: null }));
  res.json(enriched);
});

router.post("/claims", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const parsed = CreateClaimBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { policyId, triggerType, triggerValue, devicePressure, mockLocationDetected, systemIntegrityFlag } = parsed.data;
  const workerId = req.workerId!;

  const [worker] = await db.select().from(workersTable).where(eq(workersTable.id, workerId));
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const [policy] = await db.select().from(policiesTable).where(eq(policiesTable.id, policyId));
  if (!policy || policy.status !== "active") {
    res.status(400).json({ error: "No active policy found" });
    return;
  }

  let stationPressure = 1013;
  try {
    const weather = await fetchWeatherData(worker.lat, worker.lon);
    stationPressure = weather.pressure;
  } catch {}

  const threshold = triggerType === "weather" ? WEATHER_THRESHOLD : TRAFFIC_THRESHOLD;
  const fraudResult = runFraudSentry({
    devicePressure: devicePressure ?? null,
    stationPressure,
    mockLocationDetected: mockLocationDetected ?? null,
    systemIntegrityFlag: systemIntegrityFlag ?? null,
    rainfall: triggerValue,
    triggerType,
  });

  const payoutAmount = policy.coverageAmount;
  const status = fraudResult.isFlagged ? "conditional_payout" : "approved";
  const handshakeCode = fraudResult.isFlagged ? randomBytes(4).toString("hex").toUpperCase() : null;

  const [claim] = await db.insert(claimsTable).values({
    workerId,
    policyId,
    triggerType,
    triggerValue,
    triggerThreshold: threshold,
    status,
    payoutAmount,
    fraudScore: fraudResult.fraudScore,
    fraudFlags: fraudResult.fraudFlags,
    isFlagged: fraudResult.isFlagged,
    handshakeCode,
  }).returning();

  logger.info({ claimId: claim!.id, workerId, fraudScore: fraudResult.fraudScore, status }, "Claim created");

  res.status(201).json({ ...claim, workerName: null, city: null });
});

router.get("/claims/:id", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const params = GetClaimParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [claim] = await db.select().from(claimsTable).where(eq(claimsTable.id, params.data.id));
  if (!claim) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  res.json({ ...claim, workerName: null, city: null });
});

router.post("/claims/:id/verify", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const params = VerifyClaimHandshakeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = VerifyClaimHandshakeBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [claim] = await db.select().from(claimsTable).where(eq(claimsTable.id, params.data.id));
  if (!claim) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  if (claim.handshakeCode !== body.data.handshakeCode) {
    res.status(400).json({ error: "Invalid handshake code" });
    return;
  }

  const [updated] = await db.update(claimsTable).set({
    status: "approved",
    verifiedAt: new Date(),
  }).where(eq(claimsTable.id, params.data.id)).returning();

  logger.info({ claimId: params.data.id }, "Claim verified via digital handshake");
  res.json({ ...updated, workerName: null, city: null });
});

router.post("/claims/:id/payout", authMiddleware, async (req: AuthenticatedRequest, res): Promise<void> => {
  const params = ProcessClaimPayoutParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = ProcessClaimPayoutBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const [claim] = await db.select().from(claimsTable).where(eq(claimsTable.id, params.data.id));
  if (!claim) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  if (claim.status !== "approved") {
    res.status(400).json({ error: "Claim is not in approved state" });
    return;
  }

  const [updated] = await db.update(claimsTable).set({
    status: "paid",
    payoutChoice: body.data.choice,
  }).where(eq(claimsTable.id, params.data.id)).returning();

  logger.info({ claimId: params.data.id, choice: body.data.choice }, "Claim payout processed");
  res.json({ ...updated, workerName: null, city: null });
});

export default router;
